<?php
if (class_exists("WPBakeryShortCodesContainer")) {

    class WPBakeryShortCode_Cf47rs_Section_Counter extends WPBakeryShortCodesContainer
    {
    }

}