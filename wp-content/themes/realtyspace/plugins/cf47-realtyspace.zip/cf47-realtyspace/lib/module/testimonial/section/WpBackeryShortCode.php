<?php
if (class_exists("WPBakeryShortCode")) {

    class WPBakeryShortCode_Cf47rs_Section_Partners extends WPBakeryShortCode
    {
    }

}