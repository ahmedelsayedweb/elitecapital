<?php

namespace cf47\plugin\realtyspace\module\other\vcelements\button;

use cf47\themecore\vc\AbstractShortcodeView;

class ButtonView extends AbstractShortcodeView
{

}