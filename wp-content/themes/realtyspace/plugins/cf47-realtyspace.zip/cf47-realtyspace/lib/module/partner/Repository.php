<?php
namespace cf47\plugin\realtyspace\module\partner;

use cf47\themecore\AbstractQueryRepository;

/**
 * @method Entity find(int $id)
 * @method array|Entity[] find_all(array $ids = [])
 */
class Repository extends AbstractQueryRepository
{

}
