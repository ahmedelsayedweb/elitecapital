<?php
namespace cf47\plugin\realtyspace\module\testimonial;

use cf47\themecore\AbstractQueryRepository;

/**
 * @method Entity find(int $id)
 * @method array|Entity[] find_all(array $ids = [])
 * @method Entity find_one_from_loop()
 */
class Repository extends AbstractQueryRepository
{

}
